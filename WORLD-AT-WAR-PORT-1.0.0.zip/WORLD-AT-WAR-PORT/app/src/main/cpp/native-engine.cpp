#include <jni.h>
#include <android/log.h>
#include <fstream>
#include <string>
#include <cstdio>

#define LOG_TAG "WAW_PORT_SAVE"

static std::string toUtf8(JNIEnv* env, jstring value) {
    if (!value) return {};
    const char* chars = env->GetStringUTFChars(value, nullptr);
    if (!chars) return {};
    std::string result(chars);
    env->ReleaseStringUTFChars(value, chars);
    return result;
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_worldatwar_port_MainActivity_nativeEngineStatus(JNIEnv* env, jobject) {
    __android_log_print(ANDROID_LOG_INFO, LOG_TAG, "Native save engine loaded");
    return env->NewStringUTF(
        "Native C++ save engine loaded\\n"
        "Save slots: 3 local JSON files\\n"
        "Storage: application-private files directory\\n"
        "Game runtime: not implemented yet");
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_worldatwar_port_MainActivity_nativeSaveSlot(JNIEnv* env, jobject,
                                                       jstring pathValue, jstring dataValue) {
    const std::string path = toUtf8(env, pathValue);
    const std::string data = toUtf8(env, dataValue);
    if (path.empty() || data.empty()) return JNI_FALSE;
    const std::string tempPath = path + ".tmp";
    {
        std::ofstream out(tempPath, std::ios::binary | std::ios::trunc);
        if (!out.is_open()) return JNI_FALSE;
        out.write(data.data(), static_cast<std::streamsize>(data.size()));
        out.flush();
        if (!out.good()) { out.close(); std::remove(tempPath.c_str()); return JNI_FALSE; }
    }
    if (std::rename(tempPath.c_str(), path.c_str()) != 0) {
        std::remove(tempPath.c_str());
        return JNI_FALSE;
    }
    return JNI_TRUE;
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_worldatwar_port_MainActivity_nativeLoadSlot(JNIEnv* env, jobject, jstring pathValue) {
    const std::string path = toUtf8(env, pathValue);
    if (path.empty()) return nullptr;
    std::ifstream in(path, std::ios::binary);
    if (!in.is_open()) return nullptr;
    std::string data((std::istreambuf_iterator<char>(in)), std::istreambuf_iterator<char>());
    if (data.empty()) return nullptr;
    return env->NewStringUTF(data.c_str());
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_worldatwar_port_MainActivity_nativeDeleteSlot(JNIEnv* env, jobject, jstring pathValue) {
    const std::string path = toUtf8(env, pathValue);
    if (path.empty()) return JNI_FALSE;
    return std::remove(path.c_str()) == 0 ? JNI_TRUE : JNI_FALSE;
}
