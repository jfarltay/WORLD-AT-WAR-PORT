# WORLD AT WAR PORT — Dark Frontend Update

ARM64 Android launcher foundation targeting Infinix HOT 60i / Android 15.

## Version 0.3.0 — Dark cinematic interface
- New original, desaturated war-torn battlefield background.
- Slow continuous parallax movement on the background.
- Animated drifting ember particles.
- Dark field-command layout with consistent menu buttons and mode panels.
- Red selection cursor, button feedback, synthesized UI tones and optional vibration.
- Existing settings, touch sensitivity, cursor size, HUD preference, gyro option, performance panel, and ISO document picker retained.

## Important status
This is an animated launcher/interface update, not a playable Call of Duty: World at War port. The three mode buttons still show a status message. ISO selection only stores Android document access; it does not parse or execute Xbox 360 game data. Campaign, Zombies, Multiplayer, game rendering, real FPS measurement, and gameplay controls require a genuine compatible game engine and legally obtained compatible game data.

## Build
Use GitHub Actions workflow `.github/workflows/build-apk.yml`.


## Version 0.6.0
- Expanded settings for cinematic motion and visual effects.
- Persistent UI/audio/gyro preferences and graphics quality selection.
- Remembers the selected ISO document URI and display name.
- Settings reset option.
- Note: campaign/zombies/multiplayer execution and real gameplay save-state remain unavailable until the game engine is implemented.


## Version 0.7.0 — Native Save Engine foundation
- Added a native C++ save/load/delete layer using app-private storage and atomic temporary-file replacement.
- Added three save slots managed from Settings.
- Save records include selected game document reference, campaign mission index, Zombies round, multiplayer stats, play-time counter, graphics quality, schema and timestamp.
- Restoring a slot restores stored metadata/preferences; actual gameplay state cannot be captured until a compatible playable game runtime exposes state snapshots.
- Bumped Android version to 0.7.0.


## Version 0.9.0
- Added live FPS, RAM usage and session-time counters.
- Added language selector with Iraq Arabic as default, plus English, Polish, Japanese, Korean and Brazilian Portuguese for the main interface.
- Added guarded menu-button actions with error logging and user feedback.


## Version 1.0.0 — Stability and update preparation
- Reuses the UI ToneGenerator rather than releasing and recreating it on every tap.
- Adds guarded error reporting to hotspot and keyboard-triggered actions.
- Increments Android versionCode to 10 and versionName to 1.0.0.
- Android updates replace the installed app in place when applicationId and signing key match; Android does not permit silent self-installation by an ordinary app.
