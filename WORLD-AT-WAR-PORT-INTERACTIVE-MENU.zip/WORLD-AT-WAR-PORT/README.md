# WORLD AT WAR PORT

Initial Android ARM64 + C++ project foundation.

Build: open GitHub Actions and run **Build WORLD AT WAR PORT APK**.

This is a starter foundation only, not a playable game port. It does not execute Xbox 360 ISO files. A real port needs game-engine implementation and legally usable game assets.


## Included artwork
- `app/src/main/res/drawable/ic_launcher.png`: generated application icon.
- `app/src/main/res/drawable/world_at_war_menu.png`: generated launcher/menu concept artwork.

Note: the menu image is included as an asset. The current starter Activity still displays a basic status screen; integrating a fully interactive menu and game modes is a separate implementation step.


## Interactive launcher
The main menu artwork is displayed full-screen in landscape. Transparent touch zones activate:
- Start menu and mode selection
- Settings saved locally
- HUD size preference saved locally
- Device RAM and gyroscope information
- ISO document picker (selects and remembers access to an ISO)
- Exit confirmation

Campaign, Zombies, and Multiplayer tiles are menu placeholders. The game engine/runtime is not implemented, so selecting a mode does not launch the original game.
