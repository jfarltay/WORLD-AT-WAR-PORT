package com.worldatwar.port

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable

class MainActivity : Activity() {

    private var selectedGameFile: Uri? = null
    private lateinit var root: FrameLayout
    private lateinit var background: ImageView

    companion object {
        private const val PICK_GAME_FILE = 4102
        private const val PREFS = "waw_port_settings"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN
        )
        hideSystemUi()
        showMainMenu()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemUi()
    }

    @Suppress("DEPRECATION")
    private fun hideSystemUi() {
        window.decorView.systemUiVisibility =
            (View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION)
    }

    private fun showMainMenu() {
        root = FrameLayout(this)
        background = ImageView(this).apply {
            setImageResource(resources.getIdentifier(
                "world_at_war_menu", "drawable", packageName
            ))
            scaleType = ImageView.ScaleType.FIT_XY
            contentDescription = "WORLD AT WAR PORT menu artwork"
        }
        root.addView(background, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT
        ))

        // Invisible touch zones match the buttons drawn into the menu artwork.
        addHotspot(0.025f, 0.335f, 0.255f, 0.105f) { showStartDialog() }
        addHotspot(0.025f, 0.445f, 0.255f, 0.085f) { showSettings() }
        addHotspot(0.025f, 0.535f, 0.255f, 0.085f) { showHudSettings() }
        addHotspot(0.025f, 0.625f, 0.255f, 0.085f) { showPerformance() }
        addHotspot(0.025f, 0.715f, 0.255f, 0.085f) { pickGameFile() }
        addHotspot(0.025f, 0.805f, 0.255f, 0.085f) { showExitDialog() }

        // Mode cards along the bottom-right.
        addHotspot(0.405f, 0.685f, 0.19f, 0.24f) {
            unavailableMode("ZOMBIES")
        }
        addHotspot(0.605f, 0.685f, 0.19f, 0.24f) {
            unavailableMode("CAMPAIGN")
        }
        addHotspot(0.805f, 0.685f, 0.18f, 0.24f) {
            unavailableMode("MULTIPLAYER")
        }

        setContentView(root)
    }

    private fun addHotspot(
        x: Float, y: Float, width: Float, height: Float,
        action: () -> Unit
    ) {
        val touch = View(this).apply {
            setBackgroundColor(Color.TRANSPARENT)
            isClickable = true
            setOnClickListener { action() }
        }
        root.addView(touch, FrameLayout.LayoutParams(1, 1).apply {
            gravity = Gravity.TOP or Gravity.START
            // Positions are updated after the root has its measured dimensions.
        })
        touch.post {
            val w = root.width
            val h = root.height
            touch.layoutParams = FrameLayout.LayoutParams(
                (w * width).toInt().coerceAtLeast(1),
                (h * height).toInt().coerceAtLeast(1)
            ).apply {
                leftMargin = (w * x).toInt()
                topMargin = (h * y).toInt()
            }
        }
    }

    private fun showStartDialog() {
        val choices = arrayOf("اختيار ملف اللعبة", "قائمة الأطوار")
        AlertDialog.Builder(this)
            .setTitle("WORLD AT WAR PORT")
            .setItems(choices) { _, which ->
                if (which == 0) pickGameFile() else showModesDialog()
            }
            .setNegativeButton("رجوع", null)
            .show()
    }

    private fun showModesDialog() {
        AlertDialog.Builder(this)
            .setTitle("أطوار اللعبة")
            .setItems(arrayOf("Zombies", "Campaign", "Multiplayer")) { _, which ->
                val mode = arrayOf("ZOMBIES", "CAMPAIGN", "MULTIPLAYER")[which]
                unavailableMode(mode)
            }
            .setNegativeButton("رجوع", null)
            .show()
    }

    private fun unavailableMode(mode: String) {
        val message = when {
            selectedGameFile == null ->
                "اختَر ملف اللعبة أولاً. تشغيل اللعبة نفسها غير متوفر بعد."
            else ->
                "تم اختيار $mode، لكن محرك تشغيل World at War ما زال قيد التطوير."
        }
        AlertDialog.Builder(this)
            .setTitle(mode)
            .setMessage(message)
            .setPositiveButton("حسناً", null)
            .show()
    }

    private fun pickGameFile() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf(
                "application/octet-stream", "application/x-iso9660-image"
            ))
        }
        try {
            startActivityForResult(intent, PICK_GAME_FILE)
        } catch (_: Exception) {
            Toast.makeText(this, "تعذر فتح مدير الملفات", Toast.LENGTH_LONG).show()
        }
    }

    @Deprecated("Handled for compatibility with Android document picker")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == PICK_GAME_FILE && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            val name = queryDisplayName(uri) ?: uri.lastPathSegment ?: "ملف مختار"
            if (!name.lowercase().endsWith(".iso")) {
                AlertDialog.Builder(this)
                    .setTitle("نوع الملف غير مدعوم")
                    .setMessage("اختَر ملفاً بامتداد .iso")
                    .setPositiveButton("حسناً", null)
                    .show()
                return
            }
            selectedGameFile = uri
            try {
                contentResolver.takePersistableUriPermission(
                    uri, Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (_: Exception) { }
            AlertDialog.Builder(this)
                .setTitle("تم اختيار الملف")
                .setMessage("$name\n\nتم حفظ إذن الوصول للملف. هذا لا يعني أن ISO أصبح قابلاً للتشغيل بعد.")
                .setPositiveButton("حسناً", null)
                .show()
        }
    }

    private fun queryDisplayName(uri: Uri): String? {
        return try {
            contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                val index = cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
                if (cursor.moveToFirst() && index >= 0) cursor.getString(index) else null
            }
        } catch (_: Exception) { null }
    }

    private fun showSettings() {
        val prefs = getSharedPreferences(PREFS, MODE_PRIVATE)
        val labels = arrayOf("اهتزاز اللمس", "تلميحات الواجهة")
        val keys = arrayOf("vibration", "hints")
        val checks = BooleanArray(2) { prefs.getBoolean(keys[it], true) }
        AlertDialog.Builder(this)
            .setTitle("الإعدادات")
            .setMultiChoiceItems(labels, checks) { _, which, checked ->
                prefs.edit().putBoolean(keys[which], checked).apply()
            }
            .setPositiveButton("حفظ", null)
            .show()
    }

    private fun showHudSettings() {
        val prefs = getSharedPreferences(PREFS, MODE_PRIVATE)
        val values = arrayOf("HUD صغير", "HUD متوسط", "HUD كبير")
        val selected = prefs.getInt("hud_size", 1)
        AlertDialog.Builder(this)
            .setTitle("حجم أزرار التحكم")
            .setSingleChoiceItems(values, selected) { dialog, which ->
                prefs.edit().putInt("hud_size", which).apply()
                dialog.dismiss()
                Toast.makeText(this, "تم حفظ اختيار HUD", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("رجوع", null)
            .show()
    }

    private fun showPerformance() {
        val info = android.app.ActivityManager.MemoryInfo()
        (getSystemService(ACTIVITY_SERVICE) as android.app.ActivityManager)
            .getMemoryInfo(info)
        val totalGb = info.totalMem / (1024.0 * 1024.0 * 1024.0)
        val freeGb = info.availMem / (1024.0 * 1024.0 * 1024.0)
        val sensors = getSystemService(SENSOR_SERVICE) as android.hardware.SensorManager
        val gyro = sensors.getDefaultSensor(android.hardware.Sensor.TYPE_GYROSCOPE) != null
        AlertDialog.Builder(this)
            .setTitle("معلومات الجهاز")
            .setMessage(
                "RAM الجهاز: %.1f GB\nالمتاح حالياً: %.1f GB\nالجيروسكوب: %s\n\nعداد FPS الحقيقي سيضاف عند تشغيل محرك الرسوميات.".format(
                    totalGb, freeGb, if (gyro) "مدعوم" else "غير متوفر"
                )
            )
            .setPositiveButton("حسناً", null)
            .show()
    }

    private fun showExitDialog() {
        AlertDialog.Builder(this)
            .setTitle("الخروج")
            .setMessage("هل تريد إغلاق التطبيق؟")
            .setPositiveButton("خروج") { _, _ -> finish() }
            .setNegativeButton("إلغاء", null)
            .show()
    }
}
