#include <jni.h>
#include <android/log.h>
#define LOG_TAG "WAW_PORT"

extern "C"
JNIEXPORT jstring JNICALL
Java_com_worldatwar_port_MainActivity_nativeEngineStatus(JNIEnv* env, jobject) {
    __android_log_print(ANDROID_LOG_INFO, LOG_TAG, "Native ARM64 foundation loaded");
    return env->NewStringUTF(
        "Native C++ engine loaded\n"
        "Target ABI: arm64-v8a\n"
        "Status: foundation ready\n"
        "Game runtime: not implemented yet"
    );
}
