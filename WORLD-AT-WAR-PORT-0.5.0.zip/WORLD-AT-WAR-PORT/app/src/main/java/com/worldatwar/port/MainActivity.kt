package com.worldatwar.port

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.ToneGenerator
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import kotlin.math.max
import kotlin.math.min

class MainActivity : Activity(), SensorEventListener {
    private var selectedGameFile: Uri? = null
    private lateinit var root: FrameLayout
    private lateinit var cursor: View
    private lateinit var sensorManager: SensorManager
    private var gyroSensor: Sensor? = null
    private var gyroEnabled = false
    private var lastGyroTime = 0L
    private var tone: ToneGenerator? = null
    private var menuMusic: MediaPlayer? = null
    private var musicToggle: TextView? = null
    private var cursorX = 0f
    private var cursorY = 0f

    companion object {
        private const val PICK_GAME_FILE = 4102
        private const val PREFS = "waw_port_settings"
        init { System.loadLibrary("wawport") }
    }

    private val prefs by lazy { getSharedPreferences(PREFS, MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN)
        hideSystemUi()
        tone = ToneGenerator(AudioManager.STREAM_MUSIC, prefs.getInt("sound_volume", 65))
        sensorManager = getSystemService(SENSOR_SERVICE) as SensorManager
        gyroSensor = sensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE)
        gyroEnabled = prefs.getBoolean("gyro", false) && gyroSensor != null
        showMainMenu()
        startMenuMusic()
    }

    override fun onDestroy() {
        sensorManager.unregisterListener(this)
        tone?.release(); tone = null
        menuMusic?.release(); menuMusic = null
        super.onDestroy()
    }

    override fun onResume() {
        super.onResume()
        if (::root.isInitialized) startMenuMusic()
        if (gyroEnabled) gyroSensor?.let { sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME) }
    }

    override fun onPause() {
        sensorManager.unregisterListener(this)
        if (menuMusic?.isPlaying == true) menuMusic?.pause()
        super.onPause()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemUi()
    }

    @Suppress("DEPRECATION")
    private fun hideSystemUi() {
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION)
    }

    private fun playUiSound(confirm: Boolean = false) {
        if (!prefs.getBoolean("ui_sound", true)) return
        val volume = prefs.getInt("sound_volume", 65).coerceIn(0, 100)
        if (volume == 0) return
        tone?.release()
        tone = ToneGenerator(AudioManager.STREAM_MUSIC, volume)
        tone?.startTone(if (confirm) ToneGenerator.TONE_PROP_ACK else ToneGenerator.TONE_PROP_BEEP, if (confirm) 95 else 55)
    }

    private fun showMainMenu() {
        root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }

        val background = ImageView(this).apply {
            setImageResource(R.drawable.war_background)
            scaleType = ImageView.ScaleType.CENTER_CROP
            contentDescription = "Dark cinematic battlefield background"
        }
        root.addView(background, FrameLayout.LayoutParams(-1, -1))
        background.scaleX = 1.06f
        background.scaleY = 1.06f
        android.animation.ObjectAnimator.ofFloat(background, View.TRANSLATION_X, -dp(7).toFloat(), dp(7).toFloat()).apply {
            duration = 16000; repeatCount = android.animation.ValueAnimator.INFINITE
            repeatMode = android.animation.ValueAnimator.REVERSE; start()
        }
        android.animation.ObjectAnimator.ofFloat(background, View.TRANSLATION_Y, dp(3).toFloat(), -dp(3).toFloat()).apply {
            duration = 21000; repeatCount = android.animation.ValueAnimator.INFINITE
            repeatMode = android.animation.ValueAnimator.REVERSE; start()
        }

        val shade = View(this).apply {
            setBackgroundColor(Color.argb(105, 0, 0, 0))
        }
        root.addView(shade, FrameLayout.LayoutParams(-1, -1))
        root.addView(CinematicAtmosphereOverlay(), FrameLayout.LayoutParams(-1, -1))
        root.addView(EmberOverlay(), FrameLayout.LayoutParams(-1, -1))

        // Slow cinematic camera movement: the battlefield feels alive rather than like a static wallpaper.
        android.animation.ValueAnimator.ofFloat(1.06f, 1.13f).apply {
            duration = 24000L
            repeatCount = android.animation.ValueAnimator.INFINITE
            repeatMode = android.animation.ValueAnimator.REVERSE
            addUpdateListener { animator ->
                val scale = animator.animatedValue as Float
                background.scaleX = scale
                background.scaleY = scale
            }
            start()
        }

        val titlePanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(14), dp(8), dp(14), dp(4))
            setBackground(GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                intArrayOf(Color.argb(0,0,0,0), Color.argb(155,0,0,0), Color.argb(0,0,0,0))))
        }
        val title = TextView(this).apply {
            text = "WORLD AT WAR"
            setTextColor(Color.rgb(226, 222, 211))
            textSize = 29f
            typeface = android.graphics.Typeface.create("sans-serif-condensed", android.graphics.Typeface.BOLD)
            gravity = Gravity.CENTER
            letterSpacing = .12f
            setShadowLayer(dp(8).toFloat(), 0f, 0f, Color.BLACK)
        }
        val subtitle = TextView(this).apply {
            text = "MOBILE PORT  •  FIELD COMMAND"
            setTextColor(Color.rgb(190, 48, 42)); textSize = 10f
            gravity = Gravity.CENTER; letterSpacing = .22f
        }
        titlePanel.addView(title)
        android.animation.ObjectAnimator.ofFloat(title, View.ALPHA, .78f, 1f).apply {
            duration = 2100L
            repeatCount = android.animation.ValueAnimator.INFINITE
            repeatMode = android.animation.ValueAnimator.REVERSE
            start()
        }
        titlePanel.addView(subtitle)
        root.addView(titlePanel, FrameLayout.LayoutParams(-1, dp(74), Gravity.TOP or Gravity.CENTER_HORIZONTAL))

        val leftMenu = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(18), dp(8), dp(8), dp(8))
        }
        val menuItems = listOf(
            "▶   START GAME" to { showStartDialog() },
            "⚙   SETTINGS" to { showSettings() },
            "◈   HUD / CONTROLS" to { showHudSettings() },
            "▥   PERFORMANCE" to { showPerformance() },
            "▣   SELECT GAME FILE" to { pickGameFile() },
            "⏻   EXIT" to { showExitDialog() }
        )
        menuItems.forEachIndexed { index, item ->
            val button = warButton(item.first, index == 0) { item.second() }
            leftMenu.addView(button, LinearLayout.LayoutParams(dp(226), dp(43)).apply { bottomMargin = dp(7) })
        }
        root.addView(leftMenu, FrameLayout.LayoutParams(dp(255), -2, Gravity.START or Gravity.CENTER_VERTICAL).apply {
            topMargin = dp(24)
        })

        val status = TextView(this).apply {
            text = "FIELD STATUS  /  ARM64\nGYROSCOPE: ${if (gyroSensor != null) "READY" else "N/A"}\nENGINE: FOUNDATION BUILD"
            setTextColor(Color.rgb(205, 199, 184)); textSize = 9f; letterSpacing = .08f
            gravity = Gravity.END
            setPadding(dp(9), dp(7), dp(9), dp(7))
            setBackground(panelBackground(150))
        }
        root.addView(status, FrameLayout.LayoutParams(dp(170), -2, Gravity.END or Gravity.TOP).apply {
            topMargin = dp(12); marginEnd = dp(14)
        })

        val musicPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(9), dp(6), dp(9), dp(5))
            setBackground(panelBackground(165))
        }
        val musicHeader = TextView(this).apply {
            text = "MENU SOUNDTRACK"
            setTextColor(Color.rgb(210, 203, 187)); textSize = 8f
            letterSpacing = .12f; gravity = Gravity.CENTER
        }
        val musicControls = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        musicToggle = TextView(this).apply {
            text = "Ⅱ  PAUSE"
            setTextColor(Color.WHITE); textSize = 10f; gravity = Gravity.CENTER
            setPadding(dp(10), dp(5), dp(10), dp(5))
            setOnClickListener { toggleMenuMusic() }
        }
        val volumeLabel = TextView(this).apply {
            text = "VOL"; setTextColor(Color.LTGRAY); textSize = 8f
            gravity = Gravity.CENTER_VERTICAL
        }
        val musicVolume = SeekBar(this).apply {
            max = 100
            progress = prefs.getInt("music_volume", 55).coerceIn(0, 100)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seek: SeekBar?, value: Int, fromUser: Boolean) {
                    if (fromUser) {
                        prefs.edit().putInt("music_volume", value).apply()
                        setMusicVolume(value)
                    }
                }
                override fun onStartTrackingTouch(seek: SeekBar?) {}
                override fun onStopTrackingTouch(seek: SeekBar?) {}
            })
        }
        musicControls.addView(musicToggle, LinearLayout.LayoutParams(dp(82), dp(30)))
        musicControls.addView(volumeLabel, LinearLayout.LayoutParams(dp(24), dp(30)))
        musicControls.addView(musicVolume, LinearLayout.LayoutParams(dp(92), dp(30)))
        musicPanel.addView(musicHeader)
        musicPanel.addView(musicControls)
        root.addView(musicPanel, FrameLayout.LayoutParams(dp(210), -2, Gravity.END or Gravity.CENTER_VERTICAL).apply {
            marginEnd = dp(14); topMargin = dp(25)
        })

        val modeRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(dp(8), dp(5), dp(8), dp(5))
        }
        listOf("ZOMBIES", "CAMPAIGN", "MULTIPLAYER").forEach { mode ->
            val b = warButton(mode, false) { unavailableMode(mode) }
            modeRow.addView(b, LinearLayout.LayoutParams(0, dp(52), 1f).apply {
                marginStart = dp(4); marginEnd = dp(4)
            })
        }
        root.addView(modeRow, FrameLayout.LayoutParams(-1, dp(66), Gravity.BOTTOM))

        val footer = TextView(this).apply {
            text = "FIGHT  •  SURVIVE  •  ENDURE"
            setTextColor(Color.argb(210, 225, 220, 208)); textSize = 10f
            letterSpacing = .20f; gravity = Gravity.CENTER
        }
        root.addView(footer, FrameLayout.LayoutParams(-1, dp(20), Gravity.BOTTOM).apply { bottomMargin = dp(66) })
        val briefings = arrayOf(
            "FIELD REPORT  //  THE FRONT HAS FALLEN QUIET",
            "RADIO STATIC  //  NO FRIENDLY SIGNAL DETECTED",
            "OPERATION STATUS  //  WAITING FOR ORDERS",
            "WARNING  //  VISIBILITY LOW  •  ASH IN THE AIR"
        )
        val briefing = TextView(this).apply {
            text = briefings[0]
            setTextColor(Color.rgb(190, 62, 48))
            textSize = 9f
            letterSpacing = .13f
            gravity = Gravity.CENTER
            alpha = .88f
        }
        root.addView(briefing, FrameLayout.LayoutParams(-1, dp(22), Gravity.BOTTOM).apply { bottomMargin = dp(88) })
        val briefingHandler = android.os.Handler(mainLooper)
        var briefingIndex = 0
        val briefingTask = object : Runnable {
            override fun run() {
                briefing.animate().alpha(0f).setDuration(350L).withEndAction {
                    briefingIndex = (briefingIndex + 1) % briefings.size
                    briefing.text = briefings[briefingIndex]
                    briefing.animate().alpha(.9f).setDuration(650L).start()
                }.start()
                briefingHandler.postDelayed(this, 5200L)
            }
        }
        briefingHandler.postDelayed(briefingTask, 5200L)

        cursor = View(this).apply {
            setBackground(GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.argb(22, 255, 30, 30))
                setStroke(dp(2), Color.rgb(255, 35, 35))
                setSize(dp(27), dp(27))
            })
            elevation = dp(30).toFloat()
        }
        root.addView(cursor, FrameLayout.LayoutParams(dp(27), dp(27)))
        cursor.alpha = 0f
        setContentView(root)
        root.setOnTouchListener { _, event ->
            if (event.action == MotionEvent.ACTION_DOWN || event.action == MotionEvent.ACTION_MOVE) {
                moveCursor(event.x - dp(13), event.y - dp(13))
            }
            false
        }
        root.post { cursorX = root.width * .5f; cursorY = root.height * .5f; moveCursor(cursorX, cursorY, false) }
    }

    private fun startMenuMusic() {
        try {
            if (menuMusic == null) {
                menuMusic = MediaPlayer.create(this, R.raw.menu_music)?.apply { isLooping = true }
            }
            setMusicVolume(prefs.getInt("music_volume", 55))
            if (menuMusic?.isPlaying == false) menuMusic?.start()
            updateMusicToggle()
        } catch (_: Exception) {
            musicToggle?.text = "♪  UNAVAILABLE"
        }
    }

    private fun setMusicVolume(value: Int) {
        val level = value.coerceIn(0, 100) / 100f
        menuMusic?.setVolume(level, level)
    }

    private fun toggleMenuMusic() {
        val player = menuMusic
        if (player == null) {
            startMenuMusic()
            return
        }
        if (player.isPlaying) player.pause() else player.start()
        updateMusicToggle()
        playUiSound(true)
    }

    private fun updateMusicToggle() {
        musicToggle?.text = if (menuMusic?.isPlaying == true) "Ⅱ  PAUSE" else "▶  PLAY"
    }

    private fun panelBackground(alpha: Int): GradientDrawable = GradientDrawable().apply {
        setColor(Color.argb(alpha, 9, 10, 11))
        setStroke(dp(1), Color.argb(150, 150, 44, 39))
        cornerRadius = dp(3).toFloat()
    }

    private fun warButton(label: String, selected: Boolean, action: () -> Unit): TextView {
        return TextView(this).apply {
            text = label
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(13), 0, dp(8), 0)
            textSize = 12f
            letterSpacing = .08f
            typeface = android.graphics.Typeface.create("sans-serif-condensed", android.graphics.Typeface.BOLD)
            setTextColor(if (selected) Color.WHITE else Color.rgb(205, 202, 194))
            background = GradientDrawable().apply {
                setColor(if (selected) Color.argb(220, 67, 12, 12) else Color.argb(190, 8, 10, 12))
                setStroke(dp(if (selected) 2 else 1), if (selected) Color.rgb(220, 45, 38) else Color.argb(145, 170, 165, 153))
                cornerRadius = dp(3).toFloat()
            }
            isClickable = true
            setOnTouchListener { v, event ->
                if (event.action == MotionEvent.ACTION_DOWN || event.action == MotionEvent.ACTION_MOVE) {
                    val pos = IntArray(2); v.getLocationOnScreen(pos)
                    val rootPos = IntArray(2); root.getLocationOnScreen(rootPos)
                    moveCursor(pos[0] - rootPos[0] + event.x - dp(13), pos[1] - rootPos[1] + event.y - dp(13))
                }
                false
            }
            setOnClickListener {
                playUiSound(true)
                if (prefs.getBoolean("vibration", true)) {
                    val vibrator = getSystemService(VIBRATOR_SERVICE) as? android.os.Vibrator
                    if (android.os.Build.VERSION.SDK_INT >= 26) vibrator?.vibrate(android.os.VibrationEffect.createOneShot(22, 55))
                }
                animate().alpha(.72f).setDuration(65).withEndAction { animate().alpha(1f).setDuration(100).start() }.start()
                action()
            }
        }
    }

    /** Moving fog, distant light pulses and subtle film scratches for a changing war-film atmosphere. */
    private inner class CinematicAtmosphereOverlay : View(this) {
        private val fogPaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
        private val linePaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
        private var phase = 0f
        private var last = 0L
        private var flash = 0f

        init { isClickable = false }

        override fun onDraw(canvas: android.graphics.Canvas) {
            super.onDraw(canvas)
            val now = System.nanoTime()
            val dt = if (last == 0L) 16f else ((now - last) / 1_000_000f).coerceIn(1f, 40f)
            last = now
            phase += dt * .000018f
            val w = width.toFloat()
            val h = height.toFloat()

            // Low drifting fog banks, kept translucent so menu text remains readable.
            for (i in 0..2) {
                val y = h * (.57f + i * .105f) + kotlin.math.sin(phase + i * 1.7f) * h * .018f
                val drift = kotlin.math.sin(phase * .7f + i) * w * .12f
                fogPaint.shader = android.graphics.RadialGradient(
                    w * (.48f + i * .12f) + drift, y, w * .48f,
                    intArrayOf(Color.argb(0, 170, 174, 178), Color.argb(23, 145, 150, 155), Color.argb(0, 90, 95, 100)),
                    null, android.graphics.Shader.TileMode.CLAMP
                )
                canvas.drawRect(0f, y - h * .18f, w, y + h * .18f, fogPaint)
            }
            fogPaint.shader = null

            // Occasional distant sky flicker, not a bright full-screen flash.
            if (Math.random() < .0015) flash = .18f
            flash = (flash - dt * .00022f).coerceAtLeast(0f)
            if (flash > 0f) {
                fogPaint.color = Color.argb((flash * 55).toInt(), 185, 190, 198)
                canvas.drawRect(0f, 0f, w, h * .42f, fogPaint)
            }

            // Soft edge darkening creates a restrained cinematic vignette.
            fogPaint.shader = android.graphics.RadialGradient(
                w / 2f, h / 2f, max(w, h) * .72f,
                intArrayOf(Color.TRANSPARENT, Color.argb(125, 0, 0, 0)),
                floatArrayOf(.48f, 1f), android.graphics.Shader.TileMode.CLAMP
            )
            canvas.drawRect(0f, 0f, w, h, fogPaint)
            fogPaint.shader = null

            // A faint moving film line adds life without covering controls.
            linePaint.color = Color.argb(18, 220, 210, 195)
            val scanY = ((phase * 950f) % (h + dp(40))) - dp(20)
            canvas.drawRect(0f, scanY, w, scanY + dp(1), linePaint)
            postInvalidateDelayed(40L)
        }
    }

    private data class Ember(var x: Float, var y: Float, var radius: Float, var speed: Float, var drift: Float, var alpha: Int)

    private inner class EmberOverlay : View(this) {
        private val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
        private val embers = ArrayList<Ember>()
        private var lastFrame = 0L
        init {
            val random = java.util.Random(19)
            repeat(38) {
                embers.add(Ember(random.nextFloat(), random.nextFloat(), 1f + random.nextFloat() * 2.2f,
                    .000025f + random.nextFloat() * .00008f, (random.nextFloat() - .5f) * .00005f,
                    45 + random.nextInt(130)))
            }
            isClickable = false
        }
        override fun onDraw(canvas: android.graphics.Canvas) {
            super.onDraw(canvas)
            val now = System.nanoTime()
            val dt = if (lastFrame == 0L) 16f else ((now-lastFrame)/1_000_000f).coerceIn(1f,40f)
            lastFrame = now
            embers.forEach { e ->
                e.y -= e.speed * dt
                e.x += e.drift * dt
                if (e.y < -.03f || e.x < -.03f || e.x > 1.03f) {
                    e.x = Math.random().toFloat(); e.y = 1.02f
                }
                paint.color = Color.argb(e.alpha, 255, 92, 38)
                paint.setShadowLayer(5f, 0f, 0f, Color.rgb(190, 55, 20))
                canvas.drawCircle(e.x * width, e.y * height, e.radius, paint)
            }
            paint.clearShadowLayer()
            postInvalidateDelayed(32)
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun moveCursor(x: Float, y: Float, animate: Boolean = true) {
        if (!::cursor.isInitialized || !::root.isInitialized) return
        val size = dp(prefs.getInt("cursor_size", 27).coerceIn(16, 48))
        val px = x.coerceIn(0f, max(0, root.width - size).toFloat())
        val py = y.coerceIn(0f, max(0, root.height - size).toFloat())
        cursorX = px; cursorY = py
        cursor.layoutParams = FrameLayout.LayoutParams(size, size).apply { leftMargin = px.toInt(); topMargin = py.toInt() }
        cursor.alpha = 1f
        cursor.animate().cancel()
        if (animate) cursor.animate().alpha(.92f).setDuration(90).start()
    }

    private fun addHotspot(x: Float, y: Float, width: Float, height: Float, action: () -> Unit) {
        val touch = View(this).apply {
            setBackgroundColor(Color.TRANSPARENT)
            isClickable = true
            setOnTouchListener { v, event ->
                if (event.action == MotionEvent.ACTION_DOWN || event.action == MotionEvent.ACTION_MOVE) {
                    moveCursor(v.x + event.x - dp(13).toFloat(), v.y + event.y - dp(13).toFloat())
                }
                false
            }
            setOnClickListener { playUiSound(true); action() }
        }
        root.addView(touch, FrameLayout.LayoutParams(1,1))
        touch.post {
            val w = root.width; val h = root.height
            touch.layoutParams = FrameLayout.LayoutParams((w*width).toInt().coerceAtLeast(1), (h*height).toInt().coerceAtLeast(1)).apply {
                leftMargin = (w*x).toInt(); topMargin = (h*y).toInt()
            }
        }
    }

    private fun dialog(title: String, message: String) {
        AlertDialog.Builder(this).setTitle(title).setMessage(message).setPositiveButton("حسناً", null).show()
    }

    private fun showStartDialog() {
        AlertDialog.Builder(this).setTitle("WORLD AT WAR PORT")
            .setItems(arrayOf("اختيار ملف اللعبة", "قائمة الأطوار", "حالة محرك PORT")) { _, which ->
                playUiSound(true)
                when(which) { 0 -> pickGameFile(); 1 -> showModesDialog(); else -> dialog("حالة المحرك", nativeEngineStatus()) }
            }.setNegativeButton("رجوع", null).show()
    }

    private fun showModesDialog() {
        AlertDialog.Builder(this).setTitle("أطوار اللعبة").setItems(arrayOf("Zombies", "Campaign", "Multiplayer")) { _, i ->
            playUiSound(true); unavailableMode(arrayOf("ZOMBIES","CAMPAIGN","MULTIPLAYER")[i])
        }.setNegativeButton("رجوع", null).show()
    }

    private fun unavailableMode(mode: String) {
        val msg = if (selectedGameFile == null) "اختَر ملف ISO أولاً. محرك تشغيل اللعبة غير مكتمل بعد." else
            "تم اختيار $mode. قراءة ملف ISO وتشغيل اللعبة غير منفذين بعد؛ اختيار الملف وحده لا يشغّل اللعبة."
        dialog(mode, msg)
    }

    private fun pickGameFile() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("application/octet-stream", "application/x-iso9660-image"))
        }
        try { startActivityForResult(intent, PICK_GAME_FILE) }
        catch (_: Exception) { Toast.makeText(this,"تعذر فتح مدير الملفات",Toast.LENGTH_LONG).show() }
    }

    @Deprecated("Document picker compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode,resultCode,data)
        if (requestCode == PICK_GAME_FILE && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            val name = queryDisplayName(uri) ?: uri.lastPathSegment ?: "ملف مختار"
            if (!name.lowercase().endsWith(".iso")) { dialog("نوع الملف غير مدعوم", "اختَر ملفاً بامتداد .iso"); return }
            selectedGameFile = uri
            try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) { }
            dialog("تم اختيار الملف", "$name\nتم حفظ إذن الوصول. تشغيل ISO غير متوفر حتى يكتمل محرك اللعبة.")
        }
    }

    private fun queryDisplayName(uri: Uri): String? = try {
        contentResolver.query(uri,null,null,null,null)?.use { c ->
            val i = c.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
            if (c.moveToFirst() && i >= 0) c.getString(i) else null
        }
    } catch (_: Exception) { null }

    private fun showSettings() {
        val panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(22),dp(8),dp(22),dp(4)) }
        fun check(label: String, key: String, default: Boolean, changed: (Boolean)->Unit = {}) {
            val b = android.widget.CheckBox(this).apply { text=label; setTextColor(Color.WHITE); isChecked=prefs.getBoolean(key,default) }
            b.setOnCheckedChangeListener { _, v -> prefs.edit().putBoolean(key,v).apply(); changed(v) }; panel.addView(b)
        }
        panel.setBackgroundColor(Color.rgb(28,28,28))
        check("أصوات الواجهة", "ui_sound", true)
        check("اهتزاز اللمس", "vibration", true)
        check("إظهار تلميحات الواجهة", "hints", true)
        check("التحكم بالميلان (Gyroscope)", "gyro", false) { enabled ->
            gyroEnabled = enabled && gyroSensor != null
            sensorManager.unregisterListener(this)
            if (gyroEnabled) gyroSensor?.let { sensorManager.registerListener(this,it,SensorManager.SENSOR_DELAY_GAME) }
            if (enabled && gyroSensor == null) Toast.makeText(this,"الجيروسكوب غير موجود بالجهاز",Toast.LENGTH_LONG).show()
        }
        addSeek(panel,"حساسية اللمس", "touch_sensitivity", 1, 10, 5)
        addSeek(panel,"مستوى صوت الواجهة", "sound_volume", 0, 100, 65)
        AlertDialog.Builder(this).setTitle("إعدادات التحكم والصوت").setView(panel)
            .setPositiveButton("حفظ",null).setNegativeButton("رجوع",null).show()
    }

    private fun addSeek(panel: LinearLayout, label: String, key: String, minV: Int, maxV: Int, def: Int) {
        val text = TextView(this).apply { setTextColor(Color.WHITE); text="$label: ${prefs.getInt(key,def)}"; setPadding(0,dp(8),0,0) }
        val seek = SeekBar(this).apply { max=maxV-minV; progress=prefs.getInt(key,def).coerceIn(minV,maxV)-minV }
        seek.setOnSeekBarChangeListener(object: SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, user: Boolean) { val v=p+minV; text.text="$label: $v"; if(user) prefs.edit().putInt(key,v).apply() }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        panel.addView(text); panel.addView(seek)
    }

    private fun showHudSettings() {
        val panel = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(20),dp(8),dp(20),0); setBackgroundColor(Color.rgb(28,28,28)) }
        addSeek(panel,"حجم HUD", "hud_size", 1, 3, 2)
        addSeek(panel,"حجم المؤشر الأحمر", "cursor_size", 16, 48, 27)
        AlertDialog.Builder(this).setTitle("تخصيص HUD والمؤشر").setView(panel)
            .setMessage("هذه إعدادات تأسيسية؛ محرر سحب أزرار اللعب سيضاف مع بناء واجهة اللعب الفعلية.")
            .setPositiveButton("حفظ",null).setNegativeButton("رجوع",null).show()
    }

    private fun showPerformance() {
        val mem=android.app.ActivityManager.MemoryInfo()
        (getSystemService(ACTIVITY_SERVICE) as android.app.ActivityManager).getMemoryInfo(mem)
        val total=mem.totalMem/(1024.0*1024.0*1024.0); val free=mem.availMem/(1024.0*1024.0*1024.0)
        val supported=gyroSensor!=null
        val quality=prefs.getString("graphics_quality","متوازن") ?: "متوازن"
        val choices=arrayOf("توفير الطاقة", "متوازن", "جودة أعلى")
        AlertDialog.Builder(this).setTitle("الأداء والرسوميات")
            .setMessage("RAM: %.1f GB\nالمتاح الآن: %.1f GB\nGyroscope: %s\nوضع الرسوميات: %s\nعداد FPS الفعلي يحتاج محرك رسوميات يعمل.".format(total,free,if(supported)"متوفر" else "غير متوفر",quality))
            .setItems(arrayOf("توفير الطاقة", "متوازن", "جودة أعلى", "معلومات الجهاز")) { _, i ->
                if(i<3) { prefs.edit().putString("graphics_quality",choices[i]).apply(); Toast.makeText(this,"تم حفظ وضع الرسوميات التفضيلي",Toast.LENGTH_SHORT).show() }
                else showPerformance()
            }.setNegativeButton("إغلاق",null).show()
    }

    private fun showExitDialog() {
        AlertDialog.Builder(this).setTitle("الخروج").setMessage("هل تريد إغلاق التطبيق؟")
            .setPositiveButton("خروج") { _,_-> playUiSound(true); finish() }.setNegativeButton("إلغاء",null).show()
    }

    override fun onSensorChanged(event: SensorEvent?) {
        if (!gyroEnabled || event == null || !::root.isInitialized || root.width == 0) return
        val now=event.timestamp
        if(lastGyroTime!=0L) {
            val dt=((now-lastGyroTime)/1_000_000_000f).coerceIn(0f,.05f)
            val sensitivity=prefs.getInt("touch_sensitivity",5)/5f
            moveCursor(cursorX + event.values[1]*dt*root.width*.32f*sensitivity,
                cursorY + event.values[0]*dt*root.height*.32f*sensitivity, false)
        }
        lastGyroTime=now
    }
    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        val step=dp(24).toFloat()
        when(keyCode) {
            KeyEvent.KEYCODE_DPAD_LEFT -> { moveCursor(cursorX-step,cursorY); return true }
            KeyEvent.KEYCODE_DPAD_RIGHT -> { moveCursor(cursorX+step,cursorY); return true }
            KeyEvent.KEYCODE_DPAD_UP -> { moveCursor(cursorX,cursorY-step); return true }
            KeyEvent.KEYCODE_DPAD_DOWN -> { moveCursor(cursorX,cursorY+step); return true }
            KeyEvent.KEYCODE_BUTTON_A, KeyEvent.KEYCODE_ENTER -> { playUiSound(true); showStartDialog(); return true }
        }
        return super.onKeyDown(keyCode,event)
    }

    private external fun nativeEngineStatus(): String
}
