# WORLD AT WAR PORT — Dark Frontend Update

ARM64 Android launcher foundation targeting Infinix HOT 60i / Android 15.

## Version 0.3.0 — Dark cinematic interface
- New original, desaturated war-torn battlefield background.
- Slow continuous parallax movement on the background.
- Animated drifting ember particles.
- Dark field-command layout with consistent menu buttons and mode panels.
- Red selection cursor, button feedback, synthesized UI tones and optional vibration.
- Existing settings, touch sensitivity, cursor size, HUD preference, gyro option, performance panel, and ISO document picker retained.

## Important status
This is an animated launcher/interface update, not a playable Call of Duty: World at War port. The three mode buttons still show a status message. ISO selection only stores Android document access; it does not parse or execute Xbox 360 game data. Campaign, Zombies, Multiplayer, game rendering, real FPS measurement, and gameplay controls require a genuine compatible game engine and legally obtained compatible game data.

## Build
Use GitHub Actions workflow `.github/workflows/build-apk.yml`.
