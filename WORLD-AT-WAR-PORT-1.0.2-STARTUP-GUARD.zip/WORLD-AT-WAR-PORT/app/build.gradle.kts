plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.worldatwar.port"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.worldatwar.port"
        minSdk = 26
        targetSdk = 35
        versionCode = 12
        versionName = "1.0.2"
    }
    buildTypes {
        debug { isMinifyEnabled = false }
        release { isMinifyEnabled = false }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
